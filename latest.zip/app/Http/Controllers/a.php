<div class="col-md-offset-1 col-md-10 well-box">
    <div class="sticky-sign-plan"><i class="fa fa-bookmark"></i></div>
    <h2 class="post-title">
        <a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i> स्वच्छता
            अभियान</a>
    </h2>
    <div class="row">

        <div class="col-md-12">
            <img class="img-responsive" src="https://www.kayasthasamaj.in/uploads/subcategory-header-image/swachhta_abhiyan.jpg">
        </div>
        <div class="col-md-12 mt10">
            
        </div>
        <div class="col-md-12 mt10">
            <hr style="border-top: 1px solid #c2c2c2;" />
            <p>क्या आपने अपने परिवार की जानकारी कायस्थ समाज महासम्पर्क अभियान में भर
                दी है ? अगर नहीं तो अभी भरें। इसे भरने में मात्र दो मिनिट का समय अवश्य
                लगेगा परन्तु इससे कायस्थ समाज को आपका महत्वपूर्ण सहयोग प्राप्त होगा।
                कायस्थ समाज महासम्पर्क अभियान के प्रपत्र (फार्म) में जानकारी भरने पर कोई
                सदस्यता शुल्क नहीं है अभियान पूर्णता नि:शुल्क है। <a href="https://www.kayasthasamaj.in/home/signup" class="btn btn-default
            btn-xs1">Join Mahasampark Abhiyan</a></p>
        </div>
    </div>
</div>
<div class="col-md-offset-1 col-md-10 well-box">
    <div class="row">
        <div class="col-md-3 mt10">
            <img class="img-responsive" src="https://www.kayasthasamaj.in/uploads/category-related-list/c1_(4).jpg">
        </div>
        <div class="col-md-3 mt10">
            <img class="img-responsive" src="https://www.kayasthasamaj.in/uploads/category-related-list/c1_(2).jpg">
        </div>
        <div class="col-md-3 mt10">
            <img class="img-responsive" src="https://www.kayasthasamaj.in/uploads/category-related-list/c1_(3).jpg">
        </div>
        <div class="col-md-3 mt10">
            <img class="img-responsive" src="https://www.kayasthasamaj.in/uploads/category-related-list/c1_(1).jpg">
        </div>
    </div>
</div>